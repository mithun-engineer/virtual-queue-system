const API_BASE_URL = 'http://localhost:8081/api';

// Doctors data mapped to specializations
const doctorsBySpecialization = {
    'Cardiology': ['Dr. Devi Shetty', 'Dr. Naresh Trehan', 'Dr. Ashok Seth'],
    'Dermatology': ['Dr. Deepali Bhardwaj', 'Dr. Rinky Kapoor', 'Dr. Jaishree Sharad'],
    'Neurology': ['Dr. B.K. Misra', 'Dr. S.K. Raju', 'Dr. Alok Sharma'],
    'Oncology': ['Dr. Suresh Advani', 'Dr. Vinod Raina', 'Dr. Sewanti Limaye'],
    'Orthopedics': ['Dr. Nandan Rao', 'Dr. Pramod Bhor', 'Dr. Ashok Rajgopal'],
    'Pediatrics': ['Dr. Mala Sibal', 'Dr. Vikram Dua', 'Dr. Rajiv Uttam'],
    'Psychiatry': ['Dr. Samir Parikh', 'Dr. Jitendra Nagpal', 'Dr. Shweta Sharma'],
    'Radiology': ['Dr. Arvind K. Yadav', 'Dr. Sandeep Sharma', 'Dr. Vikas Kohli'],
    'Gynecology': ['Dr. Nandini Palshetkar', 'Dr. Hema Divakar', 'Dr. Rishma Pai'],
    'Anesthesiology': ['Dr. Anjali Kulkarni', 'Dr. Prakash Desai', 'Dr. Varsha Parab']
};

let currentSession = {
    gmail: '',
    name: '',
    token: null,
    doctor: '',
    specialization: ''
};

const screens = {
    login: document.getElementById('loginScreen'),
    adminLogin: document.getElementById('adminLoginScreen'),
    registration: document.getElementById('registrationScreen'),
    patientDashboard: document.getElementById('patientDashboardScreen'),
    adminDashboard: document.getElementById('adminDashboardScreen')
};

document.addEventListener('DOMContentLoaded', () => {
    showScreen('login');
    checkBackendConnection();
});

async function checkBackendConnection() {
    try {
        const response = await fetch(`${API_BASE_URL}/ping`);
        if (response.ok) {
            console.log('✅ Backend connected successfully');
        }
    } catch (error) {
        console.error('❌ Backend connection failed:', error);
    }
}

function showScreen(screenName) {
    Object.values(screens).forEach(screen => {
        if (screen) screen.classList.remove('active');
    });
    
    const screen = screens[screenName];
    if (screen) {
        screen.classList.add('active');
        if (screenName === 'adminDashboard') {
            loadAdminDashboard();
        }
    }
}

// Handle specialization change
document.getElementById('specializationSelect')?.addEventListener('change', function() {
    const doctorSelect = document.getElementById('doctorSelect');
    const specialization = this.value;
    const registerBtn = document.getElementById('registerPatientBtn');
    
    if (!specialization) {
        doctorSelect.innerHTML = '<option value="">First select specialization...</option>';
        doctorSelect.disabled = true;
        registerBtn.disabled = true;
        return;
    }
    
    const doctors = doctorsBySpecialization[specialization] || [];
    
    doctorSelect.innerHTML = '<option value="">Choose doctor...</option>';
    doctors.forEach(doctor => {
        const option = document.createElement('option');
        option.value = doctor;
        option.textContent = doctor;
        doctorSelect.appendChild(option);
    });
    
    doctorSelect.disabled = false;
    registerBtn.disabled = true;
});

document.getElementById('doctorSelect')?.addEventListener('change', function() {
    document.getElementById('registerPatientBtn').disabled = !this.value;
});

// Login with Gmail
document.getElementById('loginBtn')?.addEventListener('click', async () => {
    const gmail = document.getElementById('gmailInput').value;
    
    if (!gmail || !gmail.includes('@') || !gmail.includes('.') || !gmail.includes('@gmail.com')) {
        alert('Please enter a valid Gmail address (example@gmail.com)');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/position/${gmail}`);
        const data = await response.json();
        
        if (data.hasToken) {
            currentSession = {
                gmail: gmail,
                name: data.patientName,
                token: data.tokenNo,
                doctor: data.doctorName,
                specialization: data.specialization
            };
            updatePatientDashboard();
            showScreen('patientDashboard');
        } else if (data.patientName) {
            document.getElementById('patientGmail').value = gmail;
            document.getElementById('patientName').value = data.patientName;
            showScreen('registration');
        } else {
            document.getElementById('patientGmail').value = gmail;
            document.getElementById('patientName').value = '';
            showScreen('registration');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Error connecting to server');
    }
});

// Register Patient with all details
document.getElementById('registerPatientBtn')?.addEventListener('click', async () => {
    const name = document.getElementById('patientName').value.trim();
    const gmail = document.getElementById('patientGmail').value;
    const phone = document.getElementById('patientPhone').value.trim();
    const gender = document.getElementById('patientGender').value;
    const age = document.getElementById('patientAge').value;
    const state = document.getElementById('patientState').value.trim();
    const city = document.getElementById('patientCity').value.trim();
    const specialization = document.getElementById('specializationSelect').value;
    const doctor = document.getElementById('doctorSelect').value;
    
    // Validation
    if (!name || !gmail || !specialization || !doctor) {
        alert('Please fill all required fields');
        return;
    }
    
    if (!phone || phone.length !== 10 || !/^\d+$/.test(phone)) {
        alert('Please enter a valid 10-digit phone number');
        return;
    }
    
    if (!gender) {
        alert('Please select gender');
        return;
    }
    
    if (!age || age < 1 || age > 120) {
        alert('Please enter a valid age');
        return;
    }
    
    if (!state || !city) {
        alert('Please enter state and city');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/join`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                gmail: gmail,
                name: name,
                phone: phone,
                gender: gender,
                age: parseInt(age),
                state: state,
                city: city,
                specialization: specialization,
                doctor: doctor
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            if (data.existing) {
                alert('You already have an active token: #' + data.tokenNo);
            } else {
                alert('Registration successful! Your token: #' + data.tokenNo);
            }
            
            currentSession = {
                gmail: gmail,
                name: name,
                token: data.tokenNo,
                doctor: doctor,
                specialization: specialization
            };
            
            updatePatientDashboard();
            showScreen('patientDashboard');
        } else {
            alert('Registration failed: ' + data.message);
        }
    } catch (error) {
        console.error('Registration error:', error);
        alert('Error connecting to server');
    }
});

// Update Patient Dashboard
async function updatePatientDashboard() {
    if (!currentSession.token) return;
    
    document.getElementById('dashboardPatientName').textContent = currentSession.name;
    document.getElementById('patientTokenNumber').textContent = `#${currentSession.token}`;
    document.getElementById('patientDoctorName').textContent = currentSession.doctor;
    document.getElementById('patientSpecialization').textContent = currentSession.specialization;
    
    try {
        const response = await fetch(`${API_BASE_URL}/position/${currentSession.gmail}`);
        const data = await response.json();
        
        if (data.hasToken) {
            const position = data.position;
            const ahead = position - 1;
            
            let positionText = '';
            if (ahead === 0) {
                positionText = 'You are next!';
            } else if (ahead === 1) {
                positionText = '1 patient ahead of you';
            } else {
                positionText = `${ahead} patients ahead of you`;
            }
            document.getElementById('patientQueuePosition').textContent = positionText;
            
            const nearAlert = document.getElementById('patientNearAlert');
            if (ahead <= 1) {
                nearAlert.style.display = 'block';
                nearAlert.textContent = ahead === 0 ? 
                    'You are next! Please proceed to the counter immediately.' : 
                    'Only 1 patient ahead of you. Please be ready.';
            } else {
                nearAlert.style.display = 'none';
            }
        }
    } catch (error) {
        console.error('Error fetching position:', error);
    }
}

// Refresh Position
document.getElementById('refreshPositionBtn')?.addEventListener('click', () => {
    updatePatientDashboard();
});

// Admin Login
document.getElementById('adminLoginBtn')?.addEventListener('click', () => {
    const password = document.getElementById('adminPassword').value;
    if (password === 'admin123') {
        showScreen('adminDashboard');
        document.getElementById('adminPassword').value = '';
    } else {
        alert('Invalid password');
    }
});

// Load Admin Dashboard - UPDATED for new backend response
async function loadAdminDashboard() {
    try {
        // Load stats
        const statsResponse = await fetch(`${API_BASE_URL}/stats`);
        const statsData = await statsResponse.json();
        const stats = statsData.data || statsData;
        
        document.getElementById('totalTokens').textContent = stats.totalTokens || 0;
        document.getElementById('currentToken').textContent = stats.currentToken ? `#${stats.currentToken}` : '---';
        document.getElementById('completedTokens').textContent = stats.completedTokens || 0;
        
        // Load waiting queue
        const queueResponse = await fetch(`${API_BASE_URL}/queue`);
        const queueData = await queueResponse.json();
        const queue = queueData.data || queueData;
        
        const queueBody = document.getElementById('queueTableBody');
        if (!queue || queue.length === 0) {
            queueBody.innerHTML = '<tr><td colspan="13" class="text-center py-4 text-white-50">No patients in queue</td></tr>';
        } else {
            queueBody.innerHTML = queue.map(item => `
    <tr>
        <td>#${item.tokenNo}</td>
        <td>${item.patientName}</td>
        <td>${item.gmail}</td>
        <td>${item.phone || 'N/A'}</td>
        <td>${item.gender || 'N/A'}</td>
        <td>${item.age || 'N/A'}</td>
        <td>${item.city || 'N/A'}</td>
        <td>${item.state || 'N/A'}</td>
        <td>${item.doctorName}</td>
        <td>${item.specialization}</td>
        <td>${item.generatedAt}</td>
        <td class="text-end pe-4"><span class="badge bg-warning">Waiting</span></td>
    </tr>
`).join('');
        }
        
 // Load completed tokens with delete button
const completedResponse = await fetch(`${API_BASE_URL}/completed`);
const completedData = await completedResponse.json();
const completed = completedData.data || completedData;

const completedBody = document.getElementById('completedTableBody');
if (!completed || completed.length === 0) {
    completedBody.innerHTML = '<tr><td colspan="12" class="text-center py-4 text-white-50">No completed tokens</td></tr>';
} else {
    completedBody.innerHTML = completed.map(item => `
    <tr>
        <td>#${item.tokenNo}</td>
        <td>${item.patientName}</td>
        <td>${item.gmail}</td>
        <td>${item.phone || 'N/A'}</td>
        <td>${item.gender || 'N/A'}</td>
        <td>${item.age || 'N/A'}</td>
        <td>${item.city || 'N/A'}</td>
        <td>${item.state || 'N/A'}</td>
        <td>${item.doctorName}</td>
        <td>${item.specialization}</td>
        <td>${item.generatedAt}</td>
        <td class="text-center">
            <button class="btn btn-danger btn-sm delete-token" data-id="${item.id}">
                Delete
            </button>
        </td>
    </tr>
`).join('');
    
    // Add event listeners to delete buttons
    document.querySelectorAll('.delete-token').forEach(button => {
        button.addEventListener('click', async (e) => {
            const tokenId = e.target.getAttribute('data-id');
            await deleteCompletedToken(tokenId);
        });
    });
}
        
    } catch (error) {
        console.error('Error loading admin dashboard:', error);
    }
}
// Delete completed token and user
async function deleteCompletedToken(tokenId) {
    if (!confirm('Are you sure you want to delete this token and the patient record? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/token-complete/${tokenId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Token and patient record deleted successfully');
            loadAdminDashboard();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        console.error('Error deleting token:', error);
        alert('Error deleting token');
    }
}

// Call Next Patient
document.getElementById('callNextBtn')?.addEventListener('click', async () => {
    try {
        const response = await fetch(`${API_BASE_URL}/next`, {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`Token #${data.tokenNo} - ${data.patientName} called`);
            
            // Update stats
            document.getElementById('totalTokens').textContent = data.waitingTokens + data.completedTokens;
            document.getElementById('currentToken').textContent = data.currentToken ? `#${data.currentToken}` : '---';
            document.getElementById('completedTokens').textContent = data.completedTokens;
            
            // Reload tables
            loadAdminDashboard();
            
            // Check if current user is next
            if (currentSession.token) {
                setTimeout(() => {
                    updatePatientDashboard();
                }, 500);
            }
        } else {
            alert(data.message || 'No patients in queue');
        }
    } catch (error) {
        console.error('Error calling next:', error);
        alert('Error calling next patient');
    }
});

// Navigation
document.getElementById('showAdminLogin')?.addEventListener('click', () => showScreen('adminLogin'));
document.getElementById('backToUserLogin')?.addEventListener('click', () => showScreen('login'));
document.getElementById('registrationBackBtn')?.addEventListener('click', () => showScreen('login'));
document.getElementById('dashboardBackBtn')?.addEventListener('click', () => {
    currentSession = { gmail: '', name: '', token: null, doctor: '', specialization: '' };
    showScreen('login');
});
document.getElementById('adminDashboardBackBtn')?.addEventListener('click', () => showScreen('adminLogin'));

// Enter key handlers
document.getElementById('gmailInput')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') document.getElementById('loginBtn').click();
});

document.getElementById('adminPassword')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') document.getElementById('adminLoginBtn').click();
});

// Auto-refresh admin dashboard every 10 seconds
setInterval(() => {
    if (screens.adminDashboard.classList.contains('active')) {
        loadAdminDashboard();
    }
}, 10000);

// Auto-refresh patient position every 5 seconds
setInterval(() => {
    if (screens.patientDashboard.classList.contains('active')) {
        updatePatientDashboard();
    }
}, 5000);

/// Delete user's own token - FIXED VERSION for new backend response
document.getElementById('deleteMyTokenBtn')?.addEventListener('click', async () => {
    if (!currentSession.token) {
        alert('No active token found');
        return;
    }
    
    if (!confirm('⚠️ Are you sure you want to delete your token? This action cannot be undone.')) {
        return;
    }
    
    try {
        console.log('🔍 Looking for token number:', currentSession.token);
        
        // Get waiting queue
        const queueResponse = await fetch(`${API_BASE_URL}/queue`);
        const queueData = await queueResponse.json();
        console.log('📋 Queue response:', queueData);
        
        // Extract the data array from the response
        const queue = queueData.data || queueData;
        console.log('📋 Queue array:', queue);
        
        // Get completed tokens
        const completedResponse = await fetch(`${API_BASE_URL}/completed`);
        const completedData = await completedResponse.json();
        console.log('✅ Completed response:', completedData);
        
        // Extract the data array from the response
        const completed = completedData.data || completedData;
        console.log('✅ Completed array:', completed);
        
        // Ensure we're working with arrays
        const queueArray = Array.isArray(queue) ? queue : [];
        const completedArray = Array.isArray(completed) ? completed : [];
        
        // Find the token in waiting queue or completed
        let tokenId = null;
        
        // Search in waiting queue
        const tokenInQueue = queueArray.find(t => t.tokenNo === currentSession.token);
        if (tokenInQueue) {
            tokenId = tokenInQueue.id;
            console.log('🎯 Found token in queue:', tokenInQueue);
        }
        
        // If not found in waiting, search in completed
        if (!tokenId) {
            const tokenInCompleted = completedArray.find(t => t.tokenNo === currentSession.token);
            if (tokenInCompleted) {
                tokenId = tokenInCompleted.id;
                console.log('🎯 Found token in completed:', tokenInCompleted);
            }
        }
        
        if (!tokenId) {
            console.error('❌ Token not found in any list');
            alert('❌ Token not found in database. Please refresh and try again.');
            return;
        }
        
        console.log('🆔 Token ID to delete:', tokenId);
        
        // Delete the token
        const deleteResponse = await fetch(`${API_BASE_URL}/token-user/${tokenId}`, {
            method: 'DELETE'
        });
        
        const deleteData = await deleteResponse.json();
        console.log('📨 Delete response:', deleteData);
        
        if (deleteData.success) {
            alert('✅ Your token has been deleted successfully');
            
            // Clear current session and go back to login
            currentSession = { gmail: '', name: '', token: null, doctor: '', specialization: '' };
            showScreen('login');
            
            // Refresh admin dashboard if it's open
            if (screens.adminDashboard.classList.contains('active')) {
                loadAdminDashboard();
            }
        } else {
            alert('❌ Error: ' + deleteData.message);
        }
        
    } catch (error) {
        console.error('🔥 Error deleting token:', error);
        alert('❌ Error: ' + error.message);
    }
});